const nome = document.getElementById('btnNome');
const n1 = document.getElementById('btnN1');
const n2 = document.getElementById('btnN2');
const n3 = document.getElementById('btnN3');


nome.addEventListener('click', () => {
    
});

n1.addEventListener('click', () => {
    
});

n2.addEventListener('click', () => {
    
});

n3.addEventListener('click', () => {
    
});